Im = imread('./Images/Faaiz2.png');
CoordinateMatrix = pic2points(Im);
scatter(CoordinateMatrix (:,1), CoordinateMatrix (:,2),'.');
